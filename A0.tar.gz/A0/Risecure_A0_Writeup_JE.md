#RISECURE Assignment 0

## Pseudocode
int main(int argc, char **argv)
{
	
* bin50, bin100 run/exit cleanly on a Raspberry Pi 3 
2016-09-23-raspbian-jessie.img


## bin100
- dll's
      1625:	calling init: /lib/arm-linux-gnueabihf/libc.so.6
      1625:	calling init: /lib/arm-linux-gnueabihf/libdl.so.2
      1625:	calling init: /usr/lib/arm-linux-gnueabihf/libcrypto.so.1.0.0
      1625:	calling init: /usr/lib/arm-linux-gnueabihf/libssl.so.1.0.0
      1625:	calling init: /usr/lib/arm-linux-gnueabihf/libarmmem.so
      1625:	initialize program: ./bin100
