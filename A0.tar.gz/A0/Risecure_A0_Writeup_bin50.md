#RISECURE Assignment 0, bin 50 (Jon Ellch)

## Dependencies: 
johnycsh@raspberrypi:~/Assign0 $ LD_DEBUG=libs ./bin50  2>&1 | grep init
      1627:	calling init: /lib/arm-linux-gnueabihf/libc.so.6
      1627:	calling init: /usr/lib/arm-linux-gnueabihf/libarmmem.so
      1627:	initialize program: ./bin50

