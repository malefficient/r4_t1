int main(int argc, vhar **argv)
{

	char **var_ch;
	if (argc != 2)
		exit(-1)

	if (strlen(argv[1]) != 9
		//Incorrect flag

	// main flag validation
	var_ch = 0xff; //?
	for (i = 0; i < strlen(flag) i+=1)
	{
		if (flag[i] < var_ch)
			var_ch=flag[i]
	}
	// var_ch will be the min() byte value present in flag;
	if flag[i] - min_flag_val !=   <value in memory at 0x10774 + i>

	/*
	(gdb) x/32x 0x10774
	0x10774:        0xfc    0x07    0x01    0x00    0x20    0x08    0x01    0x00
	0x1077c:        0x30    0x08    0x01    0x00    0xf8    0x43    0x2d    0xe9
	0x10784:        0x54    0x60    0x9f    0xe5    0x54    0x50    0x9f    0xe5
	0x1078c:        0x06    0x60    0x8f    0xe0    0x05    0x50    0x8f    0xe0
	*/

    // BL, switch to THUMB
    	for (i = 0; (uint32_t)i < 9; i = i + 1) {
        	if ((uint32_t)(uint8_t)argv[1][i] - (uint32_t)flag_min_val._3_1_ !=
		//Take single byte of flag[i], extend it to 32 bits. call u32_curr_flag_val
		// u32_curr_flag_val - (u32_flag_min_val)  *must equal* 
 		//  Dereference 0x10774 + i
			
            (uint32_t)* (uint8_t *) (*      (int32_t *)0x10774 + i)) {
            puts(*(undefined4 *)0x10778);
    // WARNING: Subroutine does not return
            exit(0xffffffff);	


}

