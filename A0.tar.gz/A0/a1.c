#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <types.h>


#include <stdio.h>

void DumpHex(const void* data, size_t size) {
	char ascii[17];
	size_t i, j;
	ascii[16] = '\0';
	for (i = 0; i < size; ++i) {
		printf("%02X ", ((unsigned char*)data)[i]);
		if (((unsigned char*)data)[i] >= ' ' && ((unsigned char*)data)[i] <= '~') {
			ascii[i % 16] = ((unsigned char*)data)[i];
		} else {
			ascii[i % 16] = '.';
		}
		if ((i+1) % 8 == 0 || i+1 == size) {
			printf(" ");
			if ((i+1) % 16 == 0) {
				printf("|  %s \n", ascii);
			} else if (i+1 == size) {
				ascii[(i+1) % 16] = '\0';
				if ((i+1) % 16 <= 8) {
					printf(" ");
				}
				for (j = (i+1) % 16; j < 16; ++j) {
					printf("   ");
				}
				printf("|  %s \n", ascii);
			}
		}
	}
}


//unsigned char g_Data = {

int main(int argc, char **argv)
{
	uint32_t uVar3;
	int32_t i;
	int32_t flag_min_val;
	i=0;	
	if (argc != 2)
	{
		printf("usage: %s <flag>\n", argv[0]);
		exit(-1);
	}
	uVar3 = strlen(argv[1]);
	if (uVar3 != 9)
	{
		printf("Error. Invalid strlen: %d\n", uVar3);
		exit(-1);
	}

	flag_min_val = 0xff;
	for (i = 0; i < uVar3; i+=1)
	{
		if (argv[1][i] < flag_min_val)
			flag_min_val = argv[1][i];
	}
	printf("Flag min val is: 0x%08x\n", flag_min_val);
	DumpHex(argv[1], 9);
	for (i = 0; i < 9; i = i + 1)
	{
		argv[1][i] = ~argv[1][i];
	}
	DumpHex(argv[1], 9);
	for (i = 0; i < 9; i = i + 1)
	{
		argv[1][i] = ~argv[1][i];
	}
	DumpHex(argv[1], 9);


	

}

